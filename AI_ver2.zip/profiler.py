from hitori import HitoriSolver, get_random_board
import timeit
from memory_profiler import memory_usage


def hitori_profiler(algorithm, board_id):
    setup = f"""
from hitori import HitoriSolver, get_random_board
a = get_random_board(id={board_id})
hit = HitoriSolver(a)
"""
    stmt = f"hit.solve(algorithm='{algorithm}')"
    time_used = timeit.timeit(stmt, setup=setup, number=1)
    board = get_random_board(board_id)
    hit = HitoriSolver(board)
    res=[]
    def solver(algorithm):
        nonlocal res
        res=hit.solve(algorithm)
    mem_used = memory_usage((solver, (algorithm,)), max_usage=True)

    return res, time_used, mem_used